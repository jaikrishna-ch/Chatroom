package backend;
import com.fasterxml.jackson.*;
import java.util.ArrayList;
public class Chatroom
{
public String nameofroom;
public ArrayList<String> users=new ArrayList<String>();
public ArrayList<String> messages=new ArrayList<String>();
}